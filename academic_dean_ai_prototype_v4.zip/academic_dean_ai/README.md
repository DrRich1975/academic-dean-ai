# Academic Dean AI — Class Prototype

A Streamlit academic dashboard for comparing CMR reports, flagging underfilled and unusual sections, estimating scheduled campus activity, tracking projects/grants, and structuring monthly reports.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy for a public course demonstration

1. Create a GitHub account and a private or public repository for **code only** (do **not** commit institutional CMR files).
2. Upload `app.py`, `requirements.txt`, and `sample_cmr.csv` to the repository.
3. Sign in to https://share.streamlit.io/ with GitHub, create a new app, select the repository and main file `app.py`, and deploy.
4. Open the deployed URL, upload the provided **fictional** `sample_cmr.csv` and test each tab.
5. Capture an unobstructed screenshot of the functioning analysis for the course PDF. Paste the hosted URL into the assignment submission.

## CMR filtering and assumptions

- `Academic Org Campus == HOME`, `Class Status == A` (exact status, trimmed).
- Exclude records with `Cap Enrl` of 999 or 9999 (automatic unlimited-capacity lab components); verify this practice on future reporting formats.
- On-campus location **only** when `Loc Short Desc` is exactly `Homestead` (case-sensitive); `HOMESTEAD` is off-campus.
- Location and modality are separate; blended courses count only when explicit meeting days and in-person meeting times are supplied.
- Scheduled presence is **not real-time attendance**. The app cannot identify individual student locations.
- Section enrollments are not deduplicated student headcount. Estimated credit hours use enrolled seats × Max Units and are not official certified totals.
- Instructor summary is preliminary; cross-check the dedicated Instructors worksheet before treating it as teaching workload.
- Project/grant tracker is session-scoped only: download CSV to retain your edits.
- The machine-learning feature is Isolation Forest anomaly detection. It identifies numerical outliers, not causal problems.
- Does not embed a ChatGPT chatbot or call the OpenAI API. Use your existing ChatGPT subscription separately to polish exported monthly reports.

## Privacy

Do not upload student-identifiable, employee-confidential, grant-restricted, or other institutional protected information to public apps without authorization. Use sample data for your graded demonstration.


## Grant portfolio tab (added)

Upload the campus grant/projects Excel report using the new **Grant portfolio** tab. The app displays fund/project budget lines and produces a follow-up CSV with blank-to-confirm oversight, PI/director, award dates, and reporting deadlines. A budget line is not necessarily a distinct grant. The public demo ZIP does not include the user's real grants spreadsheet.

## Version 4 changes

- **Strategic Goals**: historical 2025–2026 campus goals with source-supported accomplishments and verification questions; separate blank planning grid for 2026–2027 (not yet approved).
- **Report Review**: upload an original monthly report `.docx`, optionally upload a prior-month final report, extract paragraph and table items, flag candidate priorities and similar descriptions, and export an editorial review CSV. This is transparent rule-based triage rather than a language-model integration; it does not automatically make editorial decisions or rewrite documents.
- **Demo launch**: sidebar button loads fictional sample CSV without an upload. Actual CMR files, monthly reports, grants, and presentation files are not bundled.
- **Cross-term caution**: comparison explicitly cautions against treating fall-vs-spring enrollment snapshots as year-over-year changes.

### Limitations

The app is not a real-time campus locator or a substitute for verified attendance and life-safety systems. Comparisons across different academic term types and registration snapshot dates should not be interpreted as true enrollment trends. Data-entry grids are session-scoped; export before closing the app. Long-term automatic reminders require the separate ChatGPT scheduled-task workflow, not Streamlit itself.
